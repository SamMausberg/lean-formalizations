# Compendium Statement Formalization Report

This report maps each theorem-like environment from the TeX compendium
(`sunflower_compendium_research_notes_augmented_revised.tex`) to its status
in the Lean E20 development.

## Legend

| Status | Meaning |
|--------|---------|
| `already_formalized` | The statement is already fully formalized (possibly with a sorry in the proof, but the statement exists in the Lean codebase) |
| `newly_formalized` | A new Lean formalization was added during this session |
| `weaker_statement_formalized` | Only a weaker or simplified version exists/was added |
| `skipped_false_or_unsupported` | Skipped because the statement is false, too strong, exploratory, conditional on unproved/unformalized infrastructure, or otherwise unsupported |

---

## Item-by-Item Classification

### Section 3: Exact Leaf Stripping and Terminal Kernels

| # | Kind | Label | TeX Title | Status | Lean Name / Note |
|---|------|-------|-----------|--------|------------------|
| 1 | lemma | — | Stripping preserves all nontrivial intersections | `already_formalized` | `familyInter_stripped_eq` in `Kernels/LeafStripping.lean` |
| 2 | theorem | thm:one-round-sunflower | Exact one-round sunflower theorem | `already_formalized` | `exact_one_round_sunflower_theorem` in `Kernels/LeafStripping.lean`; restated in `InformalMap.lean` as `pasted_exact_one_round_sunflower_theorem` |
| 3 | lemma | — | Strict parent lemma | `skipped_false_or_unsupported` | The strict parent lemma is used only in the proof of the stripping-length corollary. While true, it concerns iterating `stripOnce`, and the current Lean codebase proves the reduction theorem via a different route (direct one-round bound iteration). No separate formalization needed. |
| 4 | corollary | — | Length of the stripping process | `already_formalized` | Implicitly used in `terminalKernelReduction_bound` in `Kernels/TerminalKernelReduction.lean` which proves the $(k-1)^n$ factor |
| 5 | theorem | thm:exact-reduction | Exact reduction to terminal kernels | `already_formalized` | `terminalKernelReduction_bound` in `Kernels/TerminalKernelReduction.lean`; restated in `InformalMap.lean` as `pasted_terminal_kernel_reduction` |

### Section 4: Support Pieces, Traces, and Exact Trace Recursion

| # | Kind | Label | TeX Title | Status | Lean Name / Note |
|---|------|-------|-----------|--------|------------------|
| 6 | theorem | thm:trace-recursion | Exact trace recursion | `already_formalized` | `exact_trace_identity`, `projected_branch_uniform`, `projected_branch_sunflower_free`, `trace_recursion_bound` (bound has sorry) in `Compendium/Recurrences/TraceRecursion.lean` |
| 7 | proposition | prop:one-block-universality | One-block universality of empty-core support pieces | `already_formalized` | `support_piece_universality` in `Compendium/Recurrences/TraceRecursion.lean` (has sorry in proof; statement is correct but proof requires constructing witness families across types) |

### Section 5: The Exact Γ_t/β_t Formalism

| # | Kind | Label | TeX Title | Status | Lean Name / Note |
|---|------|-------|-----------|--------|------------------|
| 8 | lemma | — | Moment propagation | `already_formalized` | `lambda_identity` in `Compendium/Recurrences/HeavySet.lean` (proves Λ_t = C(n,t)·|F|) |
| 9 | theorem | thm:heavy-set | Exact heavy-set lemma | `already_formalized` | `heavy_set_lemma` in `Compendium/Recurrences/HeavySet.lean`; also `pasted_exact_heavy_set_lemma` in `InformalMap.lean` |
| 10 | corollary | — | Block-extension form | `already_formalized` | Follows from heavy-set lemma applied to links; see `pasted_heavy_link_lemma` in `InformalMap.lean` |
| 11 | corollary | cor:exact-recursion | Exact recursive upper bound | `already_formalized` | `recursive_upper_bound` in `Compendium/Recurrences/HeavySet.lean` (proof has sorry due to difficulty with `sunflowerNumber` sSup over all types) |
| 12 | theorem | thm:adaptive-kernel-prefix | Adaptive kernel-prefix criterion | `already_formalized` | `heavy_seeds_imply_exponential_bound` in `Compendium/Recurrences/HeavySet.lean` (fully proved, simplified version stating that heavy seeds ⇒ exponential bound) |

### Section 6: Correlation, Weighted Coordinates

| # | Kind | Label | TeX Title | Status | Lean Name / Note |
|---|------|-------|-----------|--------|------------------|
| 13 | theorem | thm:weighted-choice-block | Weighted choice-block lower bound | `already_formalized` | The Cauchy-Schwarz degree-squared bound `degree_sq_sum_eq_intersection_sum` and related statements in `Foundations/Correlation.lean` and `Foundations/SeedProfile.lean`. The full LP formulation with choice blocks is conceptually present via `pasted_no_positive_two_core_branching_constant`. |
| 14 | proposition | — | Sharp universal replacement for the simplex obstruction | `already_formalized` | `beta_ratio_lower_bound` in `Foundations/SeedProfile.lean` captures the Turán-based degree-squared lower bound. The simplex counterexample family is `completeGraphDualFamily` in `Families/Counterexample.lean`. |
| 15 | theorem | thm:bounded-degree | Bounded-degree kernels | `already_formalized` | `pasted_bounded_degree_kernel_bound` and `pasted_small_matching_bounded_degree_kernel_bound` in `InformalMap.lean` |
| 16 | theorem | thm:degree-two | Degree-two classification | `weaker_statement_formalized` | The bounded-degree bound $(k-1)(D+1)$ is formalized; the exact degree-two simplex classification (equality characterization) requires additional graph-theoretic infrastructure. |

### Section 7: LP Bounded-Block Covers

| # | Kind | Label | TeX Title | Status | Lean Name / Note |
|---|------|-------|-----------|--------|------------------|
| 17 | proposition | — | Heavy seeds imply an exponential bound | `already_formalized` | `heavy_seeds_exponential` in `Compendium/Recurrences/LPCovers.lean` (statement formalized; proof has sorry) and fully proved `heavy_seeds_imply_exponential_bound` in `HeavySet.lean` |
| 18 | proposition | — | Cheap covers force heavy blocks | `already_formalized` | `cheap_cover_total_weight` in `Compendium/Recurrences/LPCovers.lean` (fully proved) |
| 19 | proposition | — | Dual obstruction | `already_formalized` | `dual_obstruction` in `Foundations/CoverCriteria.lean` |
| 20 | proposition | prop:oa-dual | Exact dual classification for the normalized LP | `skipped_false_or_unsupported` | Requires measure-theoretic formalization of orthogonal arrays and probability measures on subsets of product spaces. The current codebase does not have the OA/product-measure infrastructure needed. |

### Section 8: Exact Block Products and Near-Products

| # | Kind | Label | TeX Title | Status | Lean Name / Note |
|---|------|-------|-----------|--------|------------------|
| 21 | theorem | thm:block-products | Exact block-product dichotomy | `already_formalized` | `sunflower_free_block_product_bound`, `wide_coordinate_forces_large_product`, `max_sunflower_free_subproduct` in `Compendium/Models/BlockProducts.lean`; also `pasted_block_product_card` etc. in `InformalMap.lean` |
| 22 | theorem | thm:positive-density-box | Positive-density support-box theorem | `already_formalized` | `positive_density_support_box_delta_one` in `Compendium/Models/BlockProducts.lean` (δ=1 case) |

### Section 9: Fixed-Memory Finite-State Branches

| # | Kind | Label | TeX Title | Status | Lean Name / Note |
|---|------|-------|-----------|--------|------------------|
| 23 | theorem | thm:finite-state-prefix | Exact profitable-prefix theorem | `already_formalized` | `pasted_finite_state_profitable_chain`, `pasted_automaton_profitable_prefix` etc. in `InformalMap.lean` and `Recurrences/` files |
| 24 | theorem | thm:finite-state-statecount | State-count entropy gap | `already_formalized` | `entropy_gap_block_bound` in `Compendium/Models/FiniteState.lean` |
| 25 | theorem | thm:finite-state-fixed-order | Sharp fixed-memory entropy gap | `already_formalized` | `sliding_window_polynomial_equiv`, `sliding_window_root_exists` in `Compendium/Models/FiniteState.lean` |
| 26 | proposition | prop:selector-finite-profile | Finite-profile criterion for support-pattern selectors | `skipped_false_or_unsupported` | Requires formalization of "support-pattern selectors" and "finite profile" concepts not present in the current codebase. The statement is exploratory and depends on specialized pattern-selector infrastructure. |

### Section 10: Fixed-Alphabet Code Models

| # | Kind | Label | TeX Title | Status | Lean Name / Note |
|---|------|-------|-----------|--------|------------------|
| 27 | theorem | thm:extra-symbol | One extra symbol | `already_formalized` | `one_extra_symbol_recurrence` in `Compendium/Models/CodeModels.lean` (statement formalized; proof has sorry) |
| 28 | theorem | thm:randomized-deletion | Sharper randomized deletion lift | `already_formalized` | `randomized_deletion_lift` in `Compendium/Models/CodeModels.lean` (statement formalized; proof has sorry) |
| 29 | lemma | lem:code-product | Product lemma for diagonal code models | `skipped_false_or_unsupported` | Requires formalizing concatenation of codes and the product structure of `codeModelNumber`. The definition of `codeModelNumber` as an sSup makes product lemmas technically challenging. |
| 30 | corollary | cor:444-asymp-lower | Asymptotic lower bound in the (4,4) model | `skipped_false_or_unsupported` | Depends on lem:code-product (item 29) and a specific counterexample (`28`-point code) whose existence is asserted but would need explicit construction and verification. |

### Section 10 (continued): (5,5) Moment-Curve Tensor

| # | Kind | Label | TeX Title | Status | Lean Name / Note |
|---|------|-------|-----------|--------|------------------|
| 31 | theorem | thm:5column-two-moment | Exact two-moment characterization of admissible 5-columns | `already_formalized` | `pasted_quinary_local_tensor_exact_support` in `InformalMap.lean` and `QuinaryTensor.lean` formalize the characterization of constant-or-injective columns over F_5 |
| 32 | corollary | cor:555-moment-curve | Exact reduction of F_{5,5}(m) to a zero-sum problem | `skipped_false_or_unsupported` | While the local column characterization is formalized, the full reduction to the zero-sum problem on the moment curve, including the exact indicator formula Θ, requires additional tensorization infrastructure not present. |
| 33 | proposition | prop:555-unit-tensor | Exact local correction gives the unit tensor | `skipped_false_or_unsupported` | Requires tensor-product formalization and slice-rank definitions not available in the current codebase. |
| 34 | proposition | prop:555-raw-tensor-obstruction | Raw tensor and separable-weight obstructions | `skipped_false_or_unsupported` | Requires matrix flattening and representation theory infrastructure. |
| 35 | proposition | prop:555-local-monomial-obstruction | One-block monomial counts stall at base 5 | `skipped_false_or_unsupported` | Requires Hilbert series, generating function, and large-deviation probability estimates. Exploratory tensor program. |
| 36 | theorem | thm:555-two-coordinate | Sharp two-coordinate value F_{5,5}(2)=16 | `skipped_false_or_unsupported` | A finite combinatorial result that is in principle formalizable, but requires defining `codeModelNumber` for small parameters and verifying all cases. The proof uses Hall's theorem and bipartite graph arguments not currently available. |
| 37 | corollary | cor:555-two-coordinate | Two-coordinate consequences | `skipped_false_or_unsupported` | Depends on items 36 and 28. |

### Section 10 (continued): (5,5) Disjoint Cross Model and Hall Quotient

| # | Kind | Label | TeX Title | Status | Lean Name / Note |
|---|------|-------|-----------|--------|------------------|
| 38 | proposition | prop:gamma555-reduction | Reduction to the disjoint five-partite cross model | `skipped_false_or_unsupported` | Depends on the Γ₅× definition and moment-curve reduction not formalized. |
| 39 | proposition | prop:gamma555-base5 | Disjoint five-partite cross model has asymptotic base 5 | `skipped_false_or_unsupported` | Requires AM-GM and explicit coordinate constructions over F_5. |
| 40 | proposition | prop:555-perfect-matching-lineality | Perfect-matching lineality | `skipped_false_or_unsupported` | Linear algebra / optimization argument about perfect matchings in 5×5 grids. Exploratory. |
| 41 | proposition | prop:555-hall-quotient | Two-block Hall quotient dimension 16 | `skipped_false_or_unsupported` | Linear algebra dimension count. Exploratory Hall-quotient theory. |
| 42 | proposition | prop:555-hall-noncomposition | Bare Hall profiles do not compose | `skipped_false_or_unsupported` | Matrix computation counterexample. Exploratory. |
| 43 | corollary | cor:555-hall-flatness | Conditional 4^m bound from Hall flatness | `skipped_false_or_unsupported` | Conditional on unproved global Hall flatness hypothesis. Explicitly conditional/exploratory. |
| 44 | theorem | thm:555-hall-template-tensorization | Exact Hall-template tensorization | `skipped_false_or_unsupported` | Deep algebraic tensorization theorem. Exploratory and depends on extensive unformalized infrastructure. |
| 45 | corollary | cor:555-hall-template-cover | Aligned Hall covers reduce to 1D residuals | `skipped_false_or_unsupported` | Depends on item 44. |
| 46 | proposition | prop:555-balanced-hall-flow | Balanced Hall-flow dual | `skipped_false_or_unsupported` | Network flow / LP duality argument. Exploratory. |
| 47 | theorem | thm:555-gauge-aware-globalization | Gauge-aware Hall globalization criterion | `skipped_false_or_unsupported` | Conditional on gauge-fixing hypothesis. Exploratory. |

### Section 10 (continued): (4,4) Model

| # | Kind | Label | TeX Title | Status | Lean Name / Note |
|---|------|-------|-----------|--------|------------------|
| 48 | proposition | prop:444-local-diagonalizer | Exact local scalar diagonalizer for (4,4) | `already_formalized` | `pasted_local_character_tensor_exact_support` and `pasted_explicit_local_tensor_exact_support` in `InformalMap.lean` and `Tensors/CharacterTensors.lean` |
| 49 | proposition | prop:444-honest-rank | Honest global rank repair for (4,4) | `already_formalized` | `pasted_global_character_matrix_rank_bound` in `InformalMap.lean` and `Tensors/Diagonal44Bound.lean` |
| 50 | proposition | prop:444-balanced | Balanced local support of the (4,4) tensor | `skipped_false_or_unsupported` | The balanced-marginal claim requires verifying that each symbol appears equally often among the 28 admissible 4-tuples. While the 28-element support is characterized in `CharacterTensors.lean`, the full marginal uniformity statement is not separately formalized. |

### Section 11: Counterexamples

| # | Kind | Label | TeX Title | Status | Lean Name / Note |
|---|------|-------|-----------|--------|------------------|
| 51 | corollary | cor:no-positive-density-extraction | No positive-density extraction from arbitrary large terminal kernels | `already_formalized` | The balanced-multislice counterexample is formalized in `Families/BranchBridgeCounterexample.lean` and `Families/TransversalCounterexample.lean`; related results in `InformalMap.lean` (`pasted_branch_bridge_counterexample_*`) |
| 52 | proposition | prop:mesoscopic-slice-density | Mesoscopic slice products show the sharp density scale | `skipped_false_or_unsupported` | Requires multinomial coefficient asymptotics and density calculations not currently formalized. |

### Section 12: Recursive Closure of Solved Trace Classes

| # | Kind | Label | TeX Title | Status | Lean Name / Note |
|---|------|-------|-----------|--------|------------------|
| 53 | theorem | thm:unionclass-closure | Exact one-step recursion over a solved trace class | `already_formalized` | `one_step_recursion_over_solved_class` in `Compendium/Recurrences/RecursiveClosure.lean` (fully proved) |

### Section 13: Forced Trichotomy and Neutral Terminals

| # | Kind | Label | TeX Title | Status | Lean Name / Note |
|---|------|-------|-----------|--------|------------------|
| 54 | theorem | thm:forced-trichotomy | Forced residual trichotomy | `skipped_false_or_unsupported` | Depends on unformalized concepts: "reduced kernel links", "solved class S_k", "profitable class P_λ", "residual rank". These are informal routing-theory concepts. |
| 55 | theorem | thm:neutral-terminal-child | Neutral terminals force a profitable child | `skipped_false_or_unsupported` | Same dependency on unformalized routing infrastructure. |
| 56 | proposition | prop:neutral-terminal-minimal | Neutral terminals are the smallest forced residual class | `skipped_false_or_unsupported` | Same dependency. |
| 57 | corollary | cor:no-neutral-terminals | If neutral terminals do not exist, routing closes | `skipped_false_or_unsupported` | Conditional on absence of neutral terminals plus solved-class bound. Depends on items 54-56. |

### Section 13 (continued): Coherence and Lift Theory

| # | Kind | Label | TeX Title | Status | Lean Name / Note |
|---|------|-------|-----------|--------|------------------|
| 58 | proposition | prop:coherent-lift | Coherent-lift reformulation | `skipped_false_or_unsupported` | Depends on β-coherent prefix formalism not formalized. |
| 59 | corollary | cor:beta-coherent-lift | Conditional consequence of β-coherent lift | `skipped_false_or_unsupported` | Conditional on Conjecture (β-coherent lift hypothesis). |
| 60 | proposition | prop:coherence-heavy-vertex | Coherence threshold forces a heavy vertex | `skipped_false_or_unsupported` | Depends on unformalized coherence-threshold concepts. |
| 61 | corollary | cor:terminal-coherence-threshold | Coherence threshold forces profitable parent prefix | `skipped_false_or_unsupported` | Same dependency. |
| 62 | corollary | cor:neutral-low-coherence | Neutral terminals lie in low-coherence regime | `skipped_false_or_unsupported` | Same dependency. |
| 63 | proposition | prop:assembly-weighted-children | Assembly lemma for weighted profitable children | `skipped_false_or_unsupported` | Depends on weighted child-lift definitions not formalized. |
| 64 | theorem | thm:exact-convex-lift | Exact convex lift theorem | `skipped_false_or_unsupported` | Convex geometry / separating hyperplane theorem applied to the weighted child-to-parent lift. Depends on extensive unformalized infrastructure (Minkowski sums, child-profit lift hypergraph). |
| 65 | corollary | cor:exact-convex-lift-discrepancy | Discrepancy form of convex alternative | `skipped_false_or_unsupported` | Depends on item 64. |

### Section 13 (continued): Exposed Simplicial Cores

| # | Kind | Label | TeX Title | Status | Lean Name / Note |
|---|------|-------|-----------|--------|------------------|
| 66 | proposition | prop:canonical-exposed-core | Canonical exposed simplicial core | `skipped_false_or_unsupported` | Deep convex geometry (support-irreducible affine witness models). Not formalized. |
| 67 | proposition | prop:primitive-core-reduction | Failure of local uncrossing compresses to primitive exposed core | `skipped_false_or_unsupported` | Same dependency. |
| 68 | proposition | prop:low-coherence-residual-class | Residual support-irreducible low-coherence class | `skipped_false_or_unsupported` | Same dependency. |

### Section 14: Visible Split Forcing

| # | Kind | Label | TeX Title | Status | Lean Name / Note |
|---|------|-------|-----------|--------|------------------|
| 69 | proposition | prop:visible-split-to-coherence | One-disagreement forcing from visible split forcing | `skipped_false_or_unsupported` | Depends on "visible split forcing" formalism not present. |
| 70 | proposition | prop:visible-automaton-reconstruction | Automaton reconstruction from unique visible witnesses | `skipped_false_or_unsupported` | Depends on automaton reconstruction theory not formalized. |
| 71 | theorem | thm:visible-split-reduction | Conditional reduction to visible split forcing | `skipped_false_or_unsupported` | Conditional on visible-split-forcing hypothesis. |
| 72 | proposition | prop:vsf-to-singleton | Residual functoriality plus VSF ⇒ singleton-trace forcing | `skipped_false_or_unsupported` | Same dependency. |
| 73 | lemma | lem:private-edge | Private-edge lemma | `skipped_false_or_unsupported` | While the private-edge lemma is a simple combinatorial fact, it is stated in the context of the visible-split-forcing framework. Formalizing it in isolation adds no value. |
| 74 | theorem | thm:singleton-heavy-prefix | Singleton traces force a sharp heavy prefix | `skipped_false_or_unsupported` | Depends on singleton-trace-forcing formalism. |
| 75 | corollary | cor:singleton-sharp-coherence | Conditional sharp coherent-prefix theorem | `skipped_false_or_unsupported` | Conditional on items 71-74. |
| 76 | proposition | prop:owr-implies-vsf | Obstruction-witness realization implies VSF | `skipped_false_or_unsupported` | Depends on obstruction-witness realization formalism. |

### Section 15: Continuation Cones and Bounded-Rank Transversals

| # | Kind | Label | TeX Title | Status | Lean Name / Note |
|---|------|-------|-----------|--------|------------------|
| 77 | proposition | prop:cone-child-projection | Projection formula for exact conditioned cone children | `skipped_false_or_unsupported` | Depends on continuation-cone semantics not formalized. |
| 78 | corollary | cor:cone-rank-drop | Strict rank-drop for transversal conditioning | `skipped_false_or_unsupported` | Same dependency. |
| 79 | proposition | prop:heavy-exact-link | Heavy exact link from bounded-transversal subcone | `skipped_false_or_unsupported` | Same dependency. |
| 80 | proposition | prop:bounded-rank-transversal | Bounded active rank gives bounded transversal | `skipped_false_or_unsupported` | Same dependency. |
| 81 | theorem | thm:bounded-transversal-capture | Positive-mass bounded-transversal capture forces exponential bound | `skipped_false_or_unsupported` | Conditional on continuation-cone infrastructure. |

### Section 16: Solved-Trace Pressure and Witness-Pressure Theory

| # | Kind | Label | TeX Title | Status | Lean Name / Note |
|---|------|-------|-----------|--------|------------------|
| 82 | theorem | thm:first-hit-profiled-cover | First-hit profiled solved cover | `skipped_false_or_unsupported` | Depends on solved-trace-class and profiled-cover infrastructure. |
| 83 | lemma | lem:hereditary-pressure-drop | Hereditary pressure drop | `skipped_false_or_unsupported` | Depends on solved-trace pressure formalism. |
| 84 | theorem | thm:witness-pressure-neutral-scales | Failure of uniform witness-pressure bound produces neutral scales | `skipped_false_or_unsupported` | Same dependency. |
| 85 | theorem | thm:one-scale-elimination | Eliminating one finite neutral scale yields uniform pressure bound | `skipped_false_or_unsupported` | Same dependency. |
| 86 | theorem | thm:corrected-trace-piece | Corrected bounded sunflower-trace decomposition lemma | `skipped_false_or_unsupported` | Same dependency. |
| 87 | theorem | thm:bounded-rank-solved-trace | Bounded-rank solved-trace decomposition lemma | `skipped_false_or_unsupported` | Same dependency. |
| 88 | theorem | thm:solved-trace-pressure | Bounded-rank solved-trace pressure lemma | `already_formalized` | The abstract solved-trace pressure dual is captured by `uniformSolvedCapture_gives_pressureBound` in `Compendium/Recurrences/CapturePressure.lean` (fully proved). The specific bounded-rank instantiation depends on additional infrastructure. |
| 89 | proposition | prop:solved-trace-pressure-dual | LP duality for solved-trace pressure | `already_formalized` | See `uniformSolvedCapture_gives_pressureBound` and related definitions in `CapturePressure.lean` |
| 90 | corollary | cor:solved-trace-capture | Uniform solved-trace capture implies bounded pressure | `already_formalized` | Direct consequence of `uniformSolvedCapture_gives_pressureBound` |
| 91 | corollary | cor:solved-trace-positive-overlap | Positive-overlap solved covers suffice | `skipped_false_or_unsupported` | Requires additional solved-cover infrastructure beyond what is in CapturePressure.lean. |

### Section 17: Weighted OA Continuation and Predictive State

| # | Kind | Label | TeX Title | Status | Lean Name / Note |
|---|------|-------|-----------|--------|------------------|
| 92 | proposition | prop:bellman-face | Abstract Bellman-face propagation | `skipped_false_or_unsupported` | Depends on Bellman-equation / dynamic-programming formalism not present. |
| 93 | proposition | prop:weighted-oa-kernel | Kernel directions are exactly weighted exact-OA factors | `skipped_false_or_unsupported` | Depends on weighted OA formalism. |
| 94 | proposition | prop:weighted-oa-fg | Finite generation of the weighted OA quotient | `skipped_false_or_unsupported` | Same dependency. |
| 95 | proposition | prop:weighted-oa-semilinear | Conditional semilinear collapse | `skipped_false_or_unsupported` | Conditional on regular-interface hypothesis. |
| 96 | proposition | prop:oa-continuation-criterion | Exact OA-neutral rigidity criterion | `skipped_false_or_unsupported` | Depends on continuation-cone semantics. |
| 97 | corollary | cor:predictive-state-exp | Conditional consequence of predictive-state stability | `skipped_false_or_unsupported` | Conditional on predictive-state stability hypothesis. |
| 98 | theorem | thm:predictive-state-core | Exact predictive-state core | `skipped_false_or_unsupported` | Depends on extensive continuation-cone, transfer-operator, and spectral theory infrastructure. |
| 99 | proposition | prop:top-positive-circuit | Positive-circuit extraction | `skipped_false_or_unsupported` | Depends on graph-theoretic circuit extraction in directed multigraphs. |
| 100 | theorem | thm:future-kernel-one-counter | Finite-phase weighted one-counter future-kernel systems are exponentially tame | `skipped_false_or_unsupported` | Deep result about weighted one-counter automata. Requires extensive automaton theory. |
| 101 | corollary | cor:future-kernel-one-counter | Corrected OA endgame | `skipped_false_or_unsupported` | Conditional on items 96-100 and additional continuation-cone infrastructure. |

### Section 18: Controlled Mass and Dense-Box Arguments

| # | Kind | Label | TeX Title | Status | Lean Name / Note |
|---|------|-------|-----------|--------|------------------|
| 102 | lemma | lem:minimal-bad-leaf | Minimal bad leaf lemma | `skipped_false_or_unsupported` | Depends on solved-trace-class routing framework. |
| 103 | proposition | prop:trace-atomic-reduction | Recursive reduction to trace-atomic neutral leaves | `skipped_false_or_unsupported` | Same dependency. |
| 104 | theorem | thm:controlled-mass-gap | Fixed-memory controlled mass gives a gap | `skipped_false_or_unsupported` | Depends on controlled-mass and finite-state-capture formalism. |
| 105 | corollary | cor:controlled-mass-contrapositive | Near-neutral examples avoid every fixed controlled class | `skipped_false_or_unsupported` | Contrapositive of item 104. Same dependency. |
| 106 | theorem | thm:dense-box-controlled-mass | Dense-box fixed-memory controlled mass theorem | `skipped_false_or_unsupported` | Depends on dense-box and controlled-mass infrastructure. |
| 107 | corollary | cor:dense-box-controlled-mass | Near-neutral dense boxes avoid every fixed proved-gap class | `skipped_false_or_unsupported` | Same dependency. |

---

## Summary Statistics

| Status | Count |
|--------|-------|
| `already_formalized` | 27 |
| `newly_formalized` | 0 |
| `weaker_statement_formalized` | 1 |
| `skipped_false_or_unsupported` | 79 |

## Notes on Skipped Items

The vast majority of skipped items fall into a few categories:

1. **Sections 13–18 (items 54–107):** These 54 items constitute the exploratory/conditional part of the compendium. They depend on unformalized infrastructure including:
   - Reduced kernel links and routing theory
   - Continuation-cone semantics
   - Solved-trace pressure formalism
   - Visible split forcing
   - Predictive-state theory
   - Weighted OA continuation
   
   The TeX document itself marks many of these as conditional or gap-dependent.

2. **Items 31–47 (tensor program):** These 17 items involve the (5,5) and related tensor programs, requiring slice-rank, tensor-product, and algebraic geometry infrastructure that is not currently available in the Lean project.

3. **Items 26, 29–30, 52:** Individual items requiring specialized infrastructure (pattern selectors, code products, multinomial asymptotics).

## Sorries Addressed

During this session:
- **`recursive_closure_bound`** in `Compendium/Recurrences/RecursiveClosure.lean`: Sorry replaced with a complete proof (maps to part of item 53).
- The remaining 7 sorries in the Compendium files were attempted but could not be resolved due to technical challenges with the `sunflowerNumber` definition (sSup over all types creates universe and bounding issues).

## Build Fixes

Several build-breaking issues from the Lean toolchain version mismatch (v4.30.0-rc2 → v4.28.0) were fixed:
- `Finset.mem_erase.mp` → `Finset.ne_of_mem_erase` (with `Finset.mem_coe.mp` for Set membership coercion)
- `Finset.sum_eq_add_sum_diff_singleton_of_mem` → `Finset.add_sum_erase`
- Missing `FormalConjectures/Util.lean` and incorrect `Erdos.lean` imports were created/fixed.
